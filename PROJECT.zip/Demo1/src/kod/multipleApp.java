package kod;

import java.util.Scanner;

public class multipleApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		int num=scan.nextInt();
		multiple b=new multiple();
		b.multiple(num);

	}

}
