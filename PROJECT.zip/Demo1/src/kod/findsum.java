package kod;

import java.util.Scanner;

public class findsum {
	public static void main(String[] args) {
	   Scanner scan=new Scanner(System.in);
	   int num=scan.nextInt();
	  double sum1=findsums(num);
	  System.out.println(sum1);
	}
	static double findsums(int num)
	
	{
		double sum=0;
		for(double i=1;i<=num;i++)
		{
			sum=sum+1/i;
			
		}
		return sum;
		
	}

}
