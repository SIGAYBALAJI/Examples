package kod;

import java.util.Scanner;

public class Evennumber1to100 {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter a number for range:");
		int num=scan.nextInt();
		for(int i=1;i<num;i++)
			if(i%2==0)
			{
				System.out.println(i);
			}else
			{
				continue;
			}
		
		
	}

}
