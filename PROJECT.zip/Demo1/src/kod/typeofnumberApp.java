package kod;

class type
{
	static void type(int num)
	{
		if(num>0)
		{
			System.out.println("enter the number is positive:"+num);
		
		}
		if(num<0)
		{
			System.out.println("enter the number is negative:"+num);
			
			
		}
		if(num==0)
		{
			System.out.println("enter the number is zero:"+num);
			
		}

}
}
