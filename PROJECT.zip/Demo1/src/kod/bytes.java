package kod;

public class bytes {
	public static void main(String[] args) {
		 byte b=10;
		short s=20;
		int ba=b+s;
		System.out.println(ba);
		
	}

}
