package kod;

public class number {

}
