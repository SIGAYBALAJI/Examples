package kod;

import java.util.Scanner;

public class Positive {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the number:");
		int num=scan.nextInt();
		if(num<0)
		{
			System.out.println("number is negative:"+num);
			
		}
		else if(num>0)
		{
			System.out.println("number is positive:"+num);
			
		}
		else
		{
			System.out.println("number is zero:"+num);
		}
	}

}
