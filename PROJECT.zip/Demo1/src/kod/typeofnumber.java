package kod;

import java.util.Scanner;

class typeApp {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	int num=scan.nextInt();
	type obj=new type();
	obj.type(num);
	
}

}
