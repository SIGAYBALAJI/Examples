package kod;
class multiple
{
	public void multiple(int num)
	{
		if(num%10==0)
		{
			System.out.println("the number is multiple of 10:");
		}
		else
		{
			System.out.println("the number is not  multiple of 10:");
			
		}
	}
}