
package kod;

public class palindrome {
	public static void main(String[] args) {
		int num=121;
		int temp=num;
		int reverse=0;
		while(num!=0)
		{
			int r=num%10;
			reverse=reverse*10+r;
			num=num/10;
		}
		if(temp==reverse)
		{
			System.out.println("the number is palindrome");
		}
		else
		{
			System.out.println("the number is not a palindrome");
		}
	}
}
	

