package kod;

public class chara {
	public static void main(String[] args) {
		String s="java";
		char[] srr= s.toCharArray();
		System.out.println(srr);
		
		
		
		
		
		
		
		
	}

}
