package kod;

import java.util.Scanner;

public class prime {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
	
		int num=scan.nextInt();
	for(int j=2;j<=num;j++)
	{
		int count=0;
	for(int i=1;i<=j;i++)
	{
		if(j%i==0)
		{
			count++;
		}
	
	}
	if(count==2)
	{
		System.out.println(j);
	}
	}
}
}
	

