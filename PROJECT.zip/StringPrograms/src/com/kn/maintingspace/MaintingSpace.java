package com.kn.maintingspace;

public class MaintingSpace {



	public void reversestring(String inputstring) {
		char[] crr=inputstring.toCharArray();
		Strinf[] srr=sortcharacter()
		
		
		
		
	}

}
